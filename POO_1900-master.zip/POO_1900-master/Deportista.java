
import java.util.*;

/**
 * 
 */
public class Deportista extends Persona {

    /**
     * Default constructor
     */
    public Deportista() {
    }

    /**
     * 
     */
    private String Fuerza;

    /**
     * 
     */
    private String Agilidad;

    /**
     * 
     */
    private String Resistencia;

    /**
     * 
     */
    private String Habilidad;

    /**
     * 
     */
    private String Peso;

    /**
     * 
     */
    public String Altura;

    /**
     * 
     */
    public String Categoria;

    /**
     * @return
     */
    public String getCategoria() {
        // TODO implement here
        return "";
    }

    /**
     * @param Categoria
     */
    public void setCategoria(void Categoria) {
        // TODO implement here
    }

}