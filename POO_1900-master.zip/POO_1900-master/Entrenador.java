
import java.util.*;

/**
 * 
 */
public class Entrenador extends Persona {

    /**
     * Default constructor
     */
    public Entrenador() {
    }

    /**
     * 
     */
    private String Actividad Creativa y disiplinarias;

    /**
     * 
     */
    private String Preparacion Tecnica y fisica;

    /**
     * 
     */
    private String Asignacion de Creditos;

    /**
     * 
     */
    public void Estudiar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Planificar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Entrenar() {
        // TODO implement here
    }

}