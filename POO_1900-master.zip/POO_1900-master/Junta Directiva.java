
import java.util.*;

/**
 * 
 */
public class Junta Directiva extends Persona {

    /**
     * Default constructor
     */
    public Junta Directiva() {
    }

    /**
     * 
     */
    private String Eventos;

    /**
     * 
     */
    private String Patrocinio;

    /**
     * 
     */
    private String Documentacion;

    /**
     * 
     */
    public void Calendarizar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Pagar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Organizar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Administrar() {
        // TODO implement here
    }

}