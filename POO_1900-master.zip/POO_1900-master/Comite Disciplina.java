
import java.util.*;

/**
 * 
 */
public class Comite Disciplina extends Persona {

    /**
     * Default constructor
     */
    public Comite Disciplina() {
    }

    /**
     * 
     */
    private void Seguridad;

    /**
     * 
     */
    private void Reglas Juego;

    /**
     * 
     */
    public void Dictar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Sancionar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Someter_a_Prueba() {
        // TODO implement here
    }

}