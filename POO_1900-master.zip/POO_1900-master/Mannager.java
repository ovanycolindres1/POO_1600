
import java.util.*;

/**
 * 
 */
public class Mannager extends Persona {

    /**
     * Default constructor
     */
    public Mannager() {
    }

    /**
     * 
     */
    private String Representacion legal;

    /**
     * 
     */
    public void Supervisar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Asesorar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Decidir() {
        // TODO implement here
    }

}