
import java.util.*;

/**
 * 
 */
public class Persona {

    /**
     * Default constructor
     */
    public Persona() {
    }

    /**
     * 
     */
    protected String Nombre;

    /**
     * 
     */
    protected String Apellido;

    /**
     * 
     */
    protected String ID;

    /**
     * 
     */
    protected String Año nacimiento;

    /**
     * 
     */
    public void mirar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void correr() {
        // TODO implement here
    }

    /**
     * 
     */
    public void patear() {
        // TODO implement here
    }

    /**
     * 
     */
    public void caminar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void comer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void golpear() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Leer() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Escribir() {
        // TODO implement here
    }

}